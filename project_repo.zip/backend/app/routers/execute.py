# execute.py: router for one-click execution
