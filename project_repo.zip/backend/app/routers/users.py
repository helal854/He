# users.py: router for user management
