# user.py: SQLAlchemy model for users and roles
