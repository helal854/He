# plan.py: SQLAlchemy model for subscription plans
