# consent.py: SQLAlchemy model for user consents
