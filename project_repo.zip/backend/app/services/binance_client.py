# binance_client.py: Binance WebSocket and REST client
