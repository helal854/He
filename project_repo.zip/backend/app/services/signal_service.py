# signal_service.py: combine TA, sentiment, leaderboard
