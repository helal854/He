# sentiment_service.py: news sentiment analysis
