# signal.py: Pydantic schema for signals
