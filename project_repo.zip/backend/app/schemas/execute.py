# execute.py: Pydantic schemas for execute endpoint
