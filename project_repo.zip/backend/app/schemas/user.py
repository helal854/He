# user.py: Pydantic schemas for user create/read
