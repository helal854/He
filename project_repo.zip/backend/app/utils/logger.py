# logger.py: Logging configuration
