# security.py: API key encryption/decryption
