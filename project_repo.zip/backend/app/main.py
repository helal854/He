# main.py: FastAPI entrypoint

from fastapi import FastAPI

app = FastAPI()
