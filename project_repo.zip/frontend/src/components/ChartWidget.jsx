// ChartWidget.jsx: Interactive chart component
