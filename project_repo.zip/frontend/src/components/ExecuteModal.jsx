// ExecuteModal.jsx: Modal for executing trades
