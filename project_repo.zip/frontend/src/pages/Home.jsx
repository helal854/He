// Home.jsx: Landing page component
