// LiveSignalsPage.jsx: Live signals table
