// load_test.js: k6 load testing script
